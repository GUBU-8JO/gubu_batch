import { Controller } from '@nestjs/common';

@Controller('scheduler')
export class SchedulerController {}
